package com.example.dndyd.shp_real;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageMetadata;
import com.google.firebase.storage.StorageReference;
import com.squareup.picasso.Picasso;

public class ShowDetail extends AppCompatActivity {
    private FirebaseDatabase firebaseDatabase = FirebaseDatabase.getInstance();
    private DatabaseReference databaseReference = firebaseDatabase.getReference();
    FirebaseStorage storage = FirebaseStorage.getInstance();
    StorageReference storageReference;
    TextView address,deposit,montly,rules;
    ImageView img;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_detail);
        firebaseDatabase=FirebaseDatabase.getInstance();

        address = (TextView)findViewById(R.id.detail_address);
        deposit = (TextView)findViewById(R.id.detail_deposit);
        montly = (TextView)findViewById(R.id.detail_montly);
        rules = (TextView)findViewById(R.id.detail_rules);
        img = (ImageView)findViewById(R.id.detail_image);
        firebaseDatabase.getReference().child("Home").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                address.setText(dataSnapshot.child("user0").child("address").getValue().toString());
                deposit.setText(dataSnapshot.child("user0").child("deposit").getValue().toString());
                montly.setText(dataSnapshot.child("user0").child("montly").getValue().toString());
                rules.setText(dataSnapshot.child("user0").child("rules").getValue().toString());
                storageReference = storage.getReferenceFromUrl(dataSnapshot.child("user0").child("photo").getValue().toString());
                storageReference.getMetadata().addOnSuccessListener(new OnSuccessListener<StorageMetadata>() {
                    @Override
                    public void onSuccess(StorageMetadata storageMetadata) {
                       Picasso.with(getApplicationContext()).load(storageMetadata.getDownloadUrl()).into(img);
                    }
                });

            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });


    }
}
