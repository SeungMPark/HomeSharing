package com.example.dndyd.shp_real;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

public class EditActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit);
    }

    public void apply(View view) {
        Toast.makeText(this,"정보 수정 완료",Toast.LENGTH_SHORT).show();
        Intent intent = new Intent(this,SelectMenu.class);
        startActivity(intent);
    }
}
