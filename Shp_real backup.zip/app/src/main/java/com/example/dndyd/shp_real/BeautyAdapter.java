package com.example.dndyd.shp_real;

import android.content.Context;
import android.content.Intent;
import android.location.Address;
import android.location.Geocoder;
import android.net.Uri;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageMetadata;
import com.google.firebase.storage.StorageReference;
import com.squareup.picasso.Picasso;

import java.io.IOException;
import java.net.URI;
import java.util.List;

public class BeautyAdapter extends RecyclerView.Adapter<BeautyAdapter.BeautyViewHolder> {
    FirebaseStorage storage = FirebaseStorage.getInstance();

    static Context mContext;

    private List<Beauty> data;

    public BeautyAdapter(List<Beauty> data, Context context) {
        this.data = data;
        this.mContext = context;
    }

    @Override
    public BeautyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        //加载item 布局文件
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.beauty_item, parent, false);
        return new BeautyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(BeautyViewHolder holder, int position) {


        final BeautyViewHolder beautyViewHolder = holder;
        Beauty beauty = data.get(position);
        StorageReference storageReference = storage.getReferenceFromUrl(beauty.getImageId());
        storageReference.getMetadata().addOnSuccessListener(new OnSuccessListener<StorageMetadata>() {
            @Override
            public void onSuccess(StorageMetadata storageMetadata) {
                Picasso.with(mContext).load(storageMetadata.getDownloadUrl()).into(beautyViewHolder.beautyImage);
            }
        });
        beautyViewHolder.nameTv.setText(beauty.getName());
    }

    @Override
    public int getItemCount() {
        return data.size();
    }

    static class BeautyViewHolder extends RecyclerView.ViewHolder {
        ImageView beautyImage;
        TextView nameTv;
        final Geocoder geocoder = new Geocoder(mContext);

        public BeautyViewHolder(View itemView) {
            super(itemView);
            beautyImage = itemView.findViewById(R.id.image_item);
            nameTv = itemView.findViewById(R.id.name_item);
            beautyImage.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(mContext, ShowDetail.class);
                    mContext.startActivity(intent);
                }
            });
            nameTv.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    List<Address> list = null;

                    String str = nameTv.getText().toString();
                    try {
                        list = geocoder.getFromLocationName
                                (str, // 지역 이름
                                        10); // 읽을 개수
                    } catch (IOException e) {
                        e.printStackTrace();
                        Log.e("test", "입출력 오류 - 서버에서 주소변환시 에러발생");
                    }

                    if (list != null) {
                        if (list.size() == 0) {

                        } else {
                            // 해당되는 주소로 인텐트 날리기
                            Address addr = list.get(0);
                            double lat = addr.getLatitude();
                            double lon = addr.getLongitude();
                            String sss = String.format("geo:%f,%f", lat, lon);
                            //   Uri.parse(sss);
                            Intent intent = new Intent(mContext, AddressActivity.class);
                            intent.putExtra("lat", lat);
                            intent.putExtra("lon", lon);
                            mContext.startActivity(intent);
                        }

                    }
                }
            });
        }
    }
}