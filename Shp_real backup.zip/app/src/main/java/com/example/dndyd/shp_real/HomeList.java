package com.example.dndyd.shp_real;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.StaggeredGridLayoutManager;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class HomeList extends AppCompatActivity {
    BeautyAdapter adapter;
    private RecyclerView recyclerView;
    private List<Beauty> data = new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_list);

        recyclerView = (RecyclerView)findViewById(R.id.recycler_view);
        StaggeredGridLayoutManager recyclerViewLayoutManager =
                new StaggeredGridLayoutManager(2, StaggeredGridLayoutManager.VERTICAL);
        recyclerView.setLayoutManager(recyclerViewLayoutManager);
        initData();
        adapter = new BeautyAdapter(data,this);
        recyclerView.setAdapter(adapter);

    }
    private void initData() {
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        database.getReference().child("Home").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                for(DataSnapshot snapshot : dataSnapshot.getChildren()) {
                    Beauty beauty =  new Beauty((String)snapshot.child("address").getValue(), (String)snapshot.child("photo").getValue());
                    data.add(beauty);
                    Toast.makeText(getApplicationContext(),beauty.getImageId(),Toast.LENGTH_SHORT).show();
                    adapter.notifyDataSetChanged();
                }
            }
            @Override
            public void onCancelled(DatabaseError databaseError) {
            }
        });
    }
}