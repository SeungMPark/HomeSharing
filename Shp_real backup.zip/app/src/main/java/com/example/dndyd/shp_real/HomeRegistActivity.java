package com.example.dndyd.shp_real;

import android.Manifest;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.net.Uri;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.iid.FirebaseInstanceId;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.text.SimpleDateFormat;
import java.util.Date;

public class HomeRegistActivity extends AppCompatActivity {

    String imageUri_db;
    Uri imageUri;
    Bitmap photo;
    ImageView homeimage;

    private static final int PICK_FROM_GALLERY = 111;
    private static final int REQ_PERMISSION_GALLERY = 123;

    private FirebaseDatabase firebaseDatabase = FirebaseDatabase.getInstance();
    private DatabaseReference databaseReference = firebaseDatabase.getReference();

    String TAG = "HomeRegistActivity";

    EditText home_address,home_deposit,home_montly,home_rules;
    Spinner home_term;
    Button regist_button,select_button;
    String tokenID = FirebaseInstanceId.getInstance().getToken();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_regist);
        regist_button = (Button)findViewById(R.id.homeRegistButton);
        init();
        regist_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                databaseReference.child("Home").child("user6").child("address").setValue(home_address.getText().toString());
                databaseReference.child("Home").child("user6").child("deposit").setValue(home_deposit.getText().toString());
                databaseReference.child("Home").child("user6").child("montly").setValue(home_montly.getText().toString());
                databaseReference.child("Home").child("user6").child("rules").setValue(home_rules.getText().toString());
                databaseReference.child("Home").child("user6").child("term").setValue(Integer.parseInt(home_term.getSelectedItem().toString()));
                uploadImage();
                databaseReference.child("Home").child("user6").child("photo").setValue(imageUri_db);
                Intent intent = new Intent(getApplicationContext(),SelectMenu.class);
                startActivity(intent);
            }
        });
    }
    public void selectHomeimagebtn(View view) {
        if(checkAppPermission(new String[] {android.Manifest.permission.READ_EXTERNAL_STORAGE})) {
            getAlbum();
        } else {
            askPermission(new String[] {Manifest.permission.READ_EXTERNAL_STORAGE}, REQ_PERMISSION_GALLERY);
        }
    }
    public boolean checkAppPermission(String[] requestPermission) {
        boolean[] requestResult = new boolean[requestPermission.length];
        for(int i=0; i<requestResult.length; i++) {
            requestResult[i] = (ContextCompat.checkSelfPermission(this,
                    requestPermission[i]) == PackageManager.PERMISSION_GRANTED);
            if(!requestResult[i]) {
                return false;
            }
        }
        return true;
    }
    public void askPermission(String[] requestPermission, int REQ_PERMISSION) {
        ActivityCompat.requestPermissions(this, requestPermission, REQ_PERMISSION);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if(requestCode == RESULT_OK) {
            getAlbum();
        }
    }
    public void getAlbum() {
        Intent intent = new Intent(Intent.ACTION_PICK);
        intent.setType(MediaStore.Images.Media.CONTENT_TYPE);
        intent.setData(MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(intent, PICK_FROM_GALLERY);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if(resultCode == RESULT_OK) {
            if(requestCode == PICK_FROM_GALLERY) {
                try {
                    imageUri = data.getData();
                    photo = MediaStore.Images.Media.getBitmap(getContentResolver(), imageUri);
                    homeimage.setImageBitmap(photo);
                } catch (Exception e) {
                    Log.e("test", e.getMessage());
                }
            }
        }
    }

    void init(){
        home_address = (EditText)findViewById(R.id.home_address);
        home_deposit = (EditText)findViewById(R.id.home_deposit);
        home_montly = (EditText)findViewById(R.id.home_montly);
        home_rules = (EditText)findViewById(R.id.home_rules);
        home_term = (Spinner)findViewById(R.id.home_term);
        select_button = (Button)findViewById(R.id.selectImagebutton);
    }

    public void uploadImage() {
        if(imageUri != null) {
            final ProgressDialog progressDialog = new ProgressDialog(this);

            progressDialog.setTitle("업로드 중..");
            progressDialog.show();

            FirebaseStorage storage = FirebaseStorage.getInstance();

            SimpleDateFormat formatter = new SimpleDateFormat("yyyyMMHH_mmss");
            Date now = new Date();
            String filename = formatter.format(now) + ".png";
            imageUri_db = "gs://gohome-563f2.appspot.com/homes/"+filename;
            StorageReference storageRef = storage.getReferenceFromUrl("gs://gohome-563f2.appspot.com/")
                    .child("homes/"+filename);
            storageRef.putFile(imageUri)
                    .addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                        @Override
                        public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                            progressDialog.dismiss();
                            Toast.makeText(getApplicationContext(), "사진 업로드 완료", Toast.LENGTH_SHORT).show();
                        }
                    })
                    .addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            progressDialog.dismiss();
                            Toast.makeText(getApplicationContext(), "사진 업로드 실패", Toast.LENGTH_SHORT).show();
                        }
                    })
                    .addOnProgressListener(new OnProgressListener<UploadTask.TaskSnapshot>() {
                        @Override
                        public void onProgress(UploadTask.TaskSnapshot taskSnapshot) {
                            @SuppressWarnings("VisibleForTests")
                            double progress = (100 * taskSnapshot.getBytesTransferred()) / taskSnapshot.getTotalByteCount();
                            progressDialog.setMessage("Uploaded " + ((int)progress) + "% ...");
                        }
                    });
        } else {
            Toast.makeText(getApplicationContext(), "파일을 먼저 선택하세요", Toast.LENGTH_SHORT).show();
        }
    }
}