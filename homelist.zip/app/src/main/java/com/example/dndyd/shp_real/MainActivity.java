package com.example.dndyd.shp_real;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class MainActivity extends AppCompatActivity {
    FirebaseAuth mAuth;
    EditText etEmail, etPassword;
    TextView signupBtn, loginBtn;
    Intent signupIntent, loginIntent;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mAuth = FirebaseAuth.getInstance();
        loginIntent = new Intent(this, SelectMenu.class);

        etEmail = findViewById(R.id.userEmail);
        etPassword = findViewById(R.id.userPassword);
        signupIntent = new Intent(this, SignupActivity.class);
        signupBtn = findViewById(R.id.signup);
        signupBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                signupIntent.putExtra("email", etEmail.getText().toString());
                startActivity(signupIntent);
            }
        });

        loginBtn = (TextView) findViewById(R.id.main_btn_login);
        loginBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mAuth.signInWithEmailAndPassword(etEmail.getText().toString(), etPassword.getText().toString())
                        .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                            @Override
                            public void onComplete(@NonNull Task<AuthResult> task) {
                                if(task.isSuccessful()) {
                                    Toast.makeText(getApplicationContext(), "로그인 성공", Toast.LENGTH_SHORT).show();
                                    startActivity(loginIntent);
                                } else {
                                    Toast.makeText(getApplicationContext(), "아이디와 패스워드를 확인하세요", Toast.LENGTH_SHORT).show();
                                }
                            }
                        });
            }
        });
    }
}