package com.example.dndyd.shp_real;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    EditText etEmail, etPassword;
    TextView signupBtn, loginBtn;
    Intent signupIntent, loginIntent;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        etEmail = findViewById(R.id.userEmail);
        etPassword = findViewById(R.id.userPassword);
        signupIntent = new Intent(this, SignupActivity.class);
        signupBtn = findViewById(R.id.signup);
        signupBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                signupIntent.putExtra("email", etEmail.getText().toString());
                signupIntent.putExtra("password", etPassword.getText().toString());
                startActivity(signupIntent);
            }
        });
        loginBtn = findViewById(R.id.main_btn_login);
        loginBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });
    }
}
