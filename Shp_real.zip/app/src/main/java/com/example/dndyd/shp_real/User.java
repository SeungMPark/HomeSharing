package com.example.dndyd.shp_real;

public class User {
    public String uid;
    public String id;
    public String pw;
    public String pwcheck;
    public String email;
    public String introduce;
    public String sex;
    public String type;
    public int birth_year, birth_month, birth_day, wakeup, sleep;
    public boolean silence, quiet, calm, pleasantness, sensitive, pet, idcard;

    public User() {
        idcard = false;
    }
    public User(boolean ismale, boolean isjunior, boolean silence, boolean quiet, boolean calm, boolean pleasantness, boolean sensitive, boolean havepet) {
        if(ismale)
            sex = "male";
        else
            sex = "female";
        if(isjunior)
            type = "junior";
        else
            type = "senior";
        if(silence)
            this.silence = true;
        else
            this.silence = false;
        if(quiet)
            this.quiet = true;
        else
            this.quiet = false;
        if(calm)
            this.calm = true;
        else
            this.calm = false;
        if(pleasantness)
            this.pleasantness = true;
        else
            this.pleasantness = false;
        if(sensitive)
            this.sensitive = true;
        else
            this.sensitive = false;
        if(havepet)
            this.pet = true;
        else
            this.pet = false;
    }
    public void setUid(String uid) {
        this.uid = uid;
    }
    public void setId(String id) {
        this.id = id;
    }
    public void setPw(String pw) {
        this.pw = pw;
    }
    public void setPwcheck(String pwcheck) {
        this.pwcheck = pwcheck;
    }
    public void setEmail(String email) {
        this.email = email;
    }
    public void setIntroduce(String introduce) {
        this.introduce = introduce;
    }
    public void setBirth_year(int year) {
        birth_year = year;
    }
    public void setBirth_month(int month) {
        birth_month = month;
    }
    public void setBirth_day(int day) {
        birth_day = day;
    }
    public void setWakeup(int wakeup) {
        this.wakeup = wakeup;
    }
    public void setSleep(int sleep) {
        this.sleep = sleep;
    }
    public void setIdcard() {
        idcard = true;
    }
    public String getUid() { return uid; }
}
