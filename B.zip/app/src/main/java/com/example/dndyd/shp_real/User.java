package com.example.dndyd.shp_real;

public class User {
    public String uid;
    public String id;
    public String pw;
    public String pwcheck;
    public String name;
    public String email;
    public String introduce;
    public String sex;
    public String type;
    public int birth_year, birth_month, birth_day, wakeup, sleep;
    public boolean silence, quiet, calm, pleasantness, sensitive, pet;
    public boolean idcard = false;
    public User() {
    }
    public User(boolean ismale, boolean isjunior, boolean silence, boolean quiet, boolean calm, boolean pleasantness, boolean sensitive, boolean havepet) {
        if(ismale)
            sex = "male";
        else
            sex = "female";
        if(isjunior)
            type = "junior";
        else
            type = "senior";
        if(silence)
            this.silence = true;
        else
            this.silence = false;
        if(quiet)
            this.quiet = true;
        else
            this.quiet = false;
        if(calm)
            this.calm = true;
        else
            this.calm = false;
        if(pleasantness)
            this.pleasantness = true;
        else
            this.pleasantness = false;
        if(sensitive)
            this.sensitive = true;
        else
            this.sensitive = false;
        if(havepet)
            this.pet = true;
        else
            this.pet = false;
    }
    public void setUid(String uid) {
        this.uid = uid;
    }
    public void setId(String id) {
        this.id = id;
    }
    public void setPw(String pw) {
        this.pw = pw;
    }
    public void setPwcheck(String pwcheck) {
        this.pwcheck = pwcheck;
    }
    public void setName(String name) {
        this.name = name;
    }
    public void setEmail(String email) {
        this.email = email;
    }
    public void setIntroduce(String introduce) {
        this.introduce = introduce;
    }
    public void setBirth_year(int year) {
        birth_year = year;
    }
    public void setBirth_month(int month) {
        birth_month = month;
    }
    public void setBirth_day(int day) {
        birth_day = day;
    }
    public void setWakeup(int wakeup) {
        this.wakeup = wakeup;
    }
    public void setSleep(int sleep) {
        this.sleep = sleep;
    }
    public void setSex(String sex) {
        this.sex = sex;
    }
    public void setType(String type) {
        this.type = type;
    }
    public void setSilence(boolean silence) {
        this.silence = silence;
    }
    ;public void setQuiet(boolean quiet) {
        this.quiet = quiet;
    }
    public void setCalm(boolean calm) {
        this.calm = calm;
    }
    public void setPleasantness(boolean pleasantness) {
        this.pleasantness = pleasantness;
    }
    public void setSensitive(boolean sensitive) {
        this.sensitive = sensitive;
    }
    public void setPet(boolean pet) {
        this.pet = pet;
    }
    public void setIdcard() {
        idcard = true;
    }
    public String getUid() { return uid; }
    public String getId() { return id; }
    public String getPw() { return pw; }
    public String getPwcheck() { return pwcheck; }
    public String getName() { return name; }
    public String getEmail() { return email; }
    public String getIntroduce() { return introduce; }
    public String getSex() { return sex; }
    public String getType() { return type; }
    public int getBirth_year() { return birth_year; }
    public int getBirth_month() { return birth_month; }
    public int getBirth_day() { return birth_day; }
    public int getWakeup() { return wakeup; }
    public int getSleep() { return sleep; }
    public boolean getSilence() { return silence; }
    public boolean getQuiet() { return quiet; }
    public boolean getCalm() { return calm; }
    public boolean getPleasantness() { return pleasantness; }
    public boolean getSensitive() { return sensitive; }
    public boolean getPet() { return pet; }
    public boolean getIdcard() { return idcard; }
}