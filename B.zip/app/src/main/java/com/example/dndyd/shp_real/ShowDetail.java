package com.example.dndyd.shp_real;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageMetadata;
import com.google.firebase.storage.StorageReference;
import com.squareup.picasso.Picasso;

public class ShowDetail extends AppCompatActivity {
    Intent intent;
    private FirebaseDatabase firebaseDatabase = FirebaseDatabase.getInstance();
    private FirebaseDatabase firebaseDatabase2 = FirebaseDatabase.getInstance();
    private DatabaseReference databaseReference = firebaseDatabase.getReference();
    FirebaseStorage storage = FirebaseStorage.getInstance();
    StorageReference storageReference;
    TextView name,character,birth,address,deposit,monthly,rules;
    ImageView img;
    String userid,d_name,d_character,d_birth,d_address,d_deposit,d_monthly,d_rules;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_detail);
        intent = getIntent();
        userid = intent.getStringExtra("id");
        firebaseDatabase=FirebaseDatabase.getInstance();
        firebaseDatabase2=FirebaseDatabase.getInstance();
        name = (TextView)findViewById(R.id.detail_name);
        character = (TextView)findViewById(R.id.detail_character);
        birth = (TextView)findViewById(R.id.detail_birth);
        address = (TextView)findViewById(R.id.detail_address);
        deposit = (TextView)findViewById(R.id.detail_deposit);
        monthly = (TextView)findViewById(R.id.detail_montly);
        rules = (TextView)findViewById(R.id.detail_rules);
        img = (ImageView)findViewById(R.id.detail_image);
        firebaseDatabase.getReference().child("User").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                for(DataSnapshot data : dataSnapshot.getChildren()) {
                    if(data.getKey().equals(userid)) {
                        d_name= data.child("name").getValue().toString();
                        d_character= data.child("calm").getValue().toString();
                        d_birth= data.child("birth_year").getValue().toString();

                        name.setText(d_name);
                        character.setText(d_character);
                        birth.setText(d_birth);
/*                        storageReference = storage.getReferenceFromUrl(dataSnapshot.child(userid).child("photo").getValue().toString());
                        storageReference.getMetadata().addOnSuccessListener(new OnSuccessListener<StorageMetadata>() {
                            @Override
                            public void onSuccess(StorageMetadata storageMetadata) {
                                Picasso.with(getApplicationContext()).load(storageMetadata.getDownloadUrl()).into(img);
                            }
                        });*/
                        break;
                    } else {
                    }
                }

            }
            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });
        firebaseDatabase2.getReference().child("Home").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                for(DataSnapshot data : dataSnapshot.getChildren()) {
                    if(data.getKey().equals(userid)) {
                        d_address= data.child("address").getValue().toString();
                        d_deposit= data.child("deposit").getValue().toString();
                        d_monthly= data.child("monthly").getValue().toString();
                        d_rules = data.child("rules").getValue().toString();
                        address.setText(d_address);
                        deposit.setText(d_deposit);
                        monthly.setText(d_monthly);
                        rules.setText(d_rules);
                        storageReference = storage.getReferenceFromUrl(dataSnapshot.child(userid).child("photo").getValue().toString());
                        storageReference.getMetadata().addOnSuccessListener(new OnSuccessListener<StorageMetadata>() {
                            @Override
                            public void onSuccess(StorageMetadata storageMetadata) {
                                Picasso.with(getApplicationContext()).load(storageMetadata.getDownloadUrl()).into(img);
                            }
                        });
                        break;
                    } else {
                    }
                }

            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });
    }
}