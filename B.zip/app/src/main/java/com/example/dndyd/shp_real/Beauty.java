package com.example.dndyd.shp_real;

public class Beauty {
    private String name;
    private String id;
    private String imageId;

    public Beauty(String name, String id, String imageId) {
        this.name = name;
        this.id = id;
        this.imageId = imageId;
    }

    public String getName() {
        return name;
    }
    public String getId() { return id; }
    public String getImageId() {
        return imageId;
    }
}