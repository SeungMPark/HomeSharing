package com.example.dndyd.shp_real;

public class Beauty {
    private String name;

    private String imageId;

    public Beauty(String name, String imageId) {
        this.name = name;
        this.imageId = imageId;
    }

    public String getName() {
        return name;
    }

    public String getImageId() {
        return imageId;
    }
}