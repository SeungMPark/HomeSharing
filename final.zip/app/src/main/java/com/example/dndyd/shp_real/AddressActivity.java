package com.example.dndyd.shp_real;

import android.app.FragmentManager;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapFragment;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;


public class AddressActivity extends AppCompatActivity
        implements OnMapReadyCallback {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_address);

        FragmentManager fragmentManager = getFragmentManager();
        MapFragment mapFragment = (MapFragment)fragmentManager
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
    }

    @Override
    public void onMapReady(final GoogleMap map) {

        Intent intent=new Intent();
        intent=getIntent();
        double lat=0;
        double lon=0;
        lat=intent.getDoubleExtra("lat",0.0);
        lon=intent.getDoubleExtra("lon",0.0);
        LatLng SEOUL = new LatLng(lat, lon);
        LatLng Konkuk=new LatLng(37.5407667, 127.0771541);


        LatLng[] latLngs={SEOUL,Konkuk};
        for(int i=0;i<1;i++) {
            MarkerOptions markerOptions = new MarkerOptions();
            markerOptions.position(latLngs[i]);
            map.setOnMarkerClickListener(new GoogleMap.OnMarkerClickListener() {
                @Override
                public boolean onMarkerClick(Marker marker) {
                    switch (marker.getTitle()) {
                        case "서울":
                            Intent i = new Intent(getApplicationContext(), AddressActivity.class);
                            startActivity(i);
                            break;
//                        case "건국":
//                            Intent i2 = new Intent(getApplicationContext(),AddressActivity.class);
//                            startActivity(i2);
//                            break;

                    }
                    return false;
                }
            });
            markerOptions.title("할아버지네집");
            markerOptions.snippet("청년 여러분들 환영합니다");
            map.addMarker(markerOptions);
        }

        map.moveCamera(CameraUpdateFactory.newLatLng(SEOUL));
        map.animateCamera(CameraUpdateFactory.zoomTo(15));
    }


}