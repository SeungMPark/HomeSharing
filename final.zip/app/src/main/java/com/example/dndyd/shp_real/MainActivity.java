package com.example.dndyd.shp_real;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.HashMap;

public class MainActivity extends AppCompatActivity {
    HashMap<String, String> infos;
    DatabaseReference db;

    FirebaseAuth mAuth;
    FirebaseUser mUser;
    EditText etEmail, etPassword;
    TextView signupBtn, loginBtn;
    Intent signupIntent, loginIntent;

    String useremail;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        infos = new HashMap<>();
        db = FirebaseDatabase.getInstance().getReference("User");
        Query query = db.orderByKey();

        query.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                for(DataSnapshot data : dataSnapshot.getChildren()) {
                    infos.put(data.getKey().toString(), data.child("email").getValue().toString());
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });
        mAuth = FirebaseAuth.getInstance();
        loginIntent = new Intent(this, SelectMenu.class);

        etEmail = findViewById(R.id.userEmail);
        etPassword = findViewById(R.id.userPassword);
        signupIntent = new Intent(this, SignupActivity.class);
        signupBtn = findViewById(R.id.signup);
        signupBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                signupIntent.putExtra("id", etEmail.getText().toString());
                startActivity(signupIntent);
            }
        });

        // 이메일 -> 아이디로 바꾸는 부분 추가 (06.10)
        // 로그인 버튼 눌렀을 때 로그인 성공 이지만 isEmailVerified가 false이면
        // sendEmailVerification 함수 호출해서 이메일 보내면서 그냥 토스트 메시지 띄울까 씌바
        // 이메일 인증을 확인하세요

        loginBtn = (TextView) findViewById(R.id.main_btn_login);
        loginBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(infos.containsKey(etEmail.getText().toString())) {
                    useremail = infos.get(etEmail.getText().toString());
                }
                mAuth.signInWithEmailAndPassword(useremail, etPassword.getText().toString())
                        .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                            @Override
                            public void onComplete(@NonNull Task<AuthResult> task) {
                                if(task.isSuccessful()) {
                                    mUser = mAuth.getCurrentUser();
                                    if(mUser.isEmailVerified()) {
                                        Toast.makeText(getApplicationContext(), "로그인 성공", Toast.LENGTH_SHORT).show();
                                        loginIntent.putExtra("userid", etEmail.getText().toString());
                                        startActivity(loginIntent);
                                    } else {
                                        Toast.makeText(getApplicationContext(), "이메일 인증이 되지 않은 아이디입니다.\n이메일을 확인해주세요", Toast.LENGTH_SHORT).show();
                                        mUser.sendEmailVerification()
                                                .addOnCompleteListener(new OnCompleteListener<Void>() {
                                                    @Override
                                                    public void onComplete(@NonNull Task<Void> task) {
                                                        if(task.isSuccessful()) {
                                                            Toast.makeText(getApplicationContext(), "이메일을 보냈습니다.", Toast.LENGTH_SHORT).show();
                                                        } else {
                                                            Toast.makeText(getApplicationContext(), "이메일 전송에 실패하였습니다.", Toast.LENGTH_SHORT).show();
                                                        }
                                                    }
                                                });
                                    }
                                } else {
                                    Toast.makeText(getApplicationContext(), "아이디와 패스워드를 확인하세요", Toast.LENGTH_SHORT).show();
                                }
                            }
                        });
            }
        });
    }
}