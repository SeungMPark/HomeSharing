package com.example.dndyd.shp_real;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;

public class SelectMenu extends AppCompatActivity {
    ImageButton btn1,btn2,btn3,btn4;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_select_menu);
        Intent intent = getIntent();
        final String user_id = intent.getStringExtra("userid");
        btn1 = (ImageButton)findViewById(R.id.select_btn1);
        btn2 = (ImageButton)findViewById(R.id.select_btn2);
        btn3 = (ImageButton)findViewById(R.id.select_btn3);
        btn4 = (ImageButton)findViewById(R.id.select_btn4);

        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),HomeMenu.class);
                intent.putExtra("userid",user_id);
                startActivity(intent);
            }
        });

        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),HomeRegistActivity.class);
                intent.putExtra("userid",user_id);
                startActivity(intent);
            }
        });

        btn3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),MatchingChatting.class);
                intent.putExtra("userid",user_id);
                startActivity(intent);
            }
        });

        btn4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),MyProfile.class);
                intent.putExtra("userid",user_id);
                startActivity(intent);
            }
        });
    }
}
