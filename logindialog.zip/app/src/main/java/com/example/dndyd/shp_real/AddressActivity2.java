package com.example.dndyd.shp_real;

import android.app.FragmentManager;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.Toast;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapFragment;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;


public class AddressActivity2 extends AppCompatActivity
        implements OnMapReadyCallback {
    double lat;
    double lon;
    //  FirebaseStorage storage = FirebaseStorage.getInstance();
    ArrayList<LatLng> latLngs;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_address);
        init();


    }
    public void init() {
        FragmentManager fragmentManager = getFragmentManager();


        MapFragment mapFragment = (MapFragment)fragmentManager
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);

    }
    @Override
    public void onMapReady(final GoogleMap map) {
        Intent intent=getIntent();
        latLngs=new ArrayList<LatLng>();
        latLngs.add(new LatLng(37.5507667, 127.0771541));
        latLngs.add(new LatLng(37.5307667, 127.0751541));
        latLngs.add(new LatLng(37.5707667, 127.0761541));
        latLngs.add(new LatLng(37.5807667, 127.0731541));
        latLngs.add(new LatLng(37.5907667, 127.0741541));



//
//        // 37.5430123,127.076096,
//        lat=intent.getDoubleExtra("lat",0);
//        lon=intent.getDoubleExtra("lon",0);
//        LatLng SEOUL = new LatLng(lat, lon);
        LatLng Konkuk=new LatLng(37.5407667, 127.0771541);

        DatabaseReference db = FirebaseDatabase.getInstance().getReference("Home");
        db.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                // id 부분에 intent로 받은 id정보 넣으면 됩니다.
                //  latLngs.clear();

                for(DataSnapshot data : dataSnapshot.getChildren()) {
                    lat= data.child("lat").getValue(Double.class);
                    lon=data.child("lon").getValue(Double.class);
                    latLngs.add(new LatLng(lat,lon));

                    Toast.makeText(AddressActivity2.this, String.valueOf(latLngs.get(0).latitude), Toast.LENGTH_SHORT).show();
                }
                String str=String.valueOf(latLngs.size());
                Toast.makeText(AddressActivity2.this, str, Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }

        });




        for(int i=0;i<latLngs.size();i++) {
            MarkerOptions markerOptions = new MarkerOptions();
            MarkerOptions position = markerOptions.position(latLngs.get(i));
            Toast.makeText(AddressActivity2.this, latLngs.get(0).toString(), Toast.LENGTH_SHORT).show();
            map.setOnMarkerClickListener(new GoogleMap.OnMarkerClickListener() {
                @Override
                public boolean onMarkerClick(Marker marker) {
                    switch (marker.getTitle()) {
                        case "1번 째 집":
                            Intent i = new Intent(getApplicationContext(), ShowDetail.class);
                            i.putExtra("id", "3343333");
                            startActivity(i);
                            break;
                        case "2번 째 집":
                            i = new Intent(getApplicationContext(), ShowDetail.class);
                            i.putExtra("id", "chlgusrjs");
                            startActivity(i);
                            break;
                        case "3번 째 집":
                            i = new Intent(getApplicationContext(),  ShowDetail.class);
                            i.putExtra("id", "gusrjs");
                            startActivity(i);
                            break;
                        case "4번 째 집":
                            i = new Intent(getApplicationContext(),  ShowDetail.class);
                            i.putExtra("id", "dndyd1231");
                            startActivity(i);
                            break;
                        case "5번 째 집":
                            i = new Intent(getApplicationContext(), ShowDetail.class);
                            i.putExtra("id", "qkrtmdals");
                            startActivity(i);
                            break;

                    }
                    return false;
                }
            });
            markerOptions.title(String.valueOf(i+1)+"번 째 집");
            markerOptions.snippet("청년 여러분들 환영합니다");
            map.addMarker(markerOptions);
        }

        map.moveCamera(CameraUpdateFactory.newLatLng(Konkuk));
        map.animateCamera(CameraUpdateFactory.zoomTo(14));
    }


}