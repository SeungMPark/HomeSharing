package com.example.dndyd.shp_real;

import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class SelectMenu extends AppCompatActivity {
    ImageButton btn1,btn2,btn3,btn4;
    DatabaseReference db;
    boolean yes = true; // 이따가 false로 바꿔줘야함
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_select_menu);
        db = FirebaseDatabase.getInstance().getReference("User");
        Intent intent = getIntent();
        final String user_id = intent.getStringExtra("userid");
//        db.orderByKey().equalTo(user_id).addListenerForSingleValueEvent(new ValueEventListener() {
//            @Override
//            public void onDataChange(DataSnapshot dataSnapshot) {
//                if(dataSnapshot.getKey().equals(user_id)) {
//                    if((boolean)dataSnapshot.child("partner_b").getValue()) {
//                        yes = true;
//                    }
//                }
//            }
//
//            @Override
//            public void onCancelled(DatabaseError databaseError) {
//
//            }
//        });
        if(yes) {
            makeDialog();
        }

        btn1 = (ImageButton)findViewById(R.id.select_btn1);
        btn2 = (ImageButton)findViewById(R.id.select_btn2);
        btn3 = (ImageButton)findViewById(R.id.select_btn3);
        btn4 = (ImageButton)findViewById(R.id.select_btn4);

        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),HomeMenu.class);
                intent.putExtra("userid",user_id);
                startActivity(intent);
            }
        });

        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),HomeRegistActivity.class);
                intent.putExtra("userid",user_id);
                startActivity(intent);
            }
        });

        btn3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),MatchingChatting.class);
                intent.putExtra("userid",user_id);
                startActivity(intent);
            }
        });

        btn4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),MyProfile.class);
                intent.putExtra("userid",user_id);
                startActivity(intent);
            }
        });
    }
    public void makeDialog() {
        LayoutInflater dialog = LayoutInflater.from(this);
        View dialogLayout = dialog.inflate(R.layout.layout_partnercheck, null);
        final Dialog checkDialog = new Dialog(this);

        checkDialog.setTitle("회원님이 등록한 집에 신청인이 있습니다!");
        checkDialog.setContentView(dialogLayout);
        checkDialog.show();

        TextView partnerid = (TextView)dialogLayout.findViewById(R.id.partner_id_textView);
        Button yeah = (Button)dialogLayout.findViewById(R.id.partner_yesbtn);
        Button nope = (Button)dialogLayout.findViewById(R.id.partner_nobtn);
        yeah.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 텍스트뷰에 있는 아이디 인텐트로 넘겨서 정보 보여주는 화면(MyProfile 레이아웃 그대로 쓰면 될듯)으로 넘어가면 될듯
            }
        });
        nope.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkDialog.cancel();
            }
        });
    }
}
