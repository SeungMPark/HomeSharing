package com.example.hyungun.home2;

import android.app.Dialog;
import android.app.Fragment;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Toast;

public class MainSettings extends Fragment {
    Button editBtn;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
    {
        final LayoutInflater dialog = LayoutInflater.from(getContext());
        final View dialogLayout = dialog.inflate(R.layout.layout_dialog, null);
        final Button btn_ok = (Button)dialogLayout.findViewById(R.id.edit_passwordOKBtn);
        final Button btn_cancel = (Button)dialogLayout.findViewById(R.id.edit_passwordCancelBtn);
        View view = inflater.inflate(R.layout.activity_main_my, container, false);
        editBtn = (Button)view.findViewById(R.id.profile_editBtn);
        editBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final Dialog pwDialog = new Dialog(getContext());
                pwDialog.setTitle("비밀번호를 입력해주세요");
                pwDialog.setContentView(dialogLayout);
                pwDialog.show();
                btn_ok.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        // 현재 비밀번호가 맞다면 (check하는 부분 넣어줘야됨)
                        // 정보 수정하는 곳으로 고고

                        Intent intent = new Intent(getActivity(), EditActivity.class);
                        startActivity(intent);
                    }
                });
                btn_cancel.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        pwDialog.cancel();
                    }
                });

            }
        });

        return view;
    }
    public void showDialog() {
       }
}