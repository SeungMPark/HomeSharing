package com.example.hyungun.home2;

import android.app.Fragment;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.StaggeredGridLayoutManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class MainWeChat extends Fragment
{
	private RecyclerView recyclerView;
	private List<Beauty> data = new ArrayList<>();
	int i = 0;
	View v;
	TextView tv ;
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
	{
		v = inflater.inflate(R.layout.wechat_view,container,false);
		recyclerView = (RecyclerView)v.findViewById(R.id.recycler_view);
		StaggeredGridLayoutManager recyclerViewLayoutManager =
				new StaggeredGridLayoutManager(2, StaggeredGridLayoutManager.VERTICAL);
		recyclerView.setLayoutManager(recyclerViewLayoutManager);
		initData();
		BeautyAdapter adapter = new BeautyAdapter(data,getActivity());
		recyclerView.setAdapter(adapter);

		recyclerView.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
					//해당 포지션에 있는 애 구해가지고
					//그 집정보랑 같이 intent 날리면됨
				Toast.makeText(getContext(),"뭐씨발놈아",Toast.LENGTH_SHORT).show();
				Intent intent = new Intent(getContext(),EditActivity.class);
				startActivity(intent);
			}
		});

		return v;
	}
	private void initData() {
		Beauty beauty;
			beauty = new Beauty("美女" + i, R.drawable.home);
			data.add(beauty);
			beauty = new Beauty("美女" + i, R.mipmap.ic_launcher);
			data.add(beauty);
			beauty = new Beauty("美女" + i, R.mipmap.ic_launcher);
			data.add(beauty);
			beauty = new Beauty("美女" + i, R.mipmap.ic_launcher);
			data.add(beauty);
			beauty = new Beauty("美女" + i, R.mipmap.ic_launcher);
			data.add(beauty);
			beauty = new Beauty("美女" + i, R.mipmap.ic_launcher);
			data.add(beauty);
			beauty = new Beauty("美女" + i, R.mipmap.ic_launcher);
			data.add(beauty);
			beauty = new Beauty("美女" + i, R.mipmap.ic_launcher);
			data.add(beauty);
			beauty = new Beauty("美女" + i, R.mipmap.ic_launcher);
			data.add(beauty);
			beauty = new Beauty("美女" + i, R.mipmap.ic_launcher);
			data.add(beauty);

	}
}