package com.example.hyungun.home2;

import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainLayoutActivity extends AppCompatActivity implements View.OnClickListener{

        private MainWeChat mWeChat;
        private MainFriend mFriend;
        private MainAddress mAddress;
        private MainSettings mSettings;
        private LinearLayout mTabBtnWeChat;
        private LinearLayout mTabBtnFriend;
        private LinearLayout mTabBtnAddress;
        private LinearLayout mTabBtnSettings;
        private FragmentManager fragmentManager;

        TextView t;

        @Override
        protected void onCreate(Bundle savedInstanceState) {
                super.onCreate(savedInstanceState);
                setContentView(R.layout.activity_main_layout);
                initViews();
                fragmentManager = getFragmentManager();
                setTabSelection(0);
                t = (TextView) findViewById(R.id.Title1);
                t.setText("집 목록");
        }

        private void initViews()
        {

                mTabBtnWeChat = (LinearLayout) findViewById(R.id.TabBtnWeChat);
                mTabBtnFriend = (LinearLayout) findViewById(R.id.TabBtnFriend);
                mTabBtnAddress = (LinearLayout) findViewById(R.id.TabBtnAddress);
                mTabBtnSettings = (LinearLayout) findViewById(R.id.TabBtnSettings);

                mTabBtnWeChat.setOnClickListener(this);
                mTabBtnFriend.setOnClickListener(this);
                mTabBtnAddress.setOnClickListener(this);
                mTabBtnSettings.setOnClickListener(this);
        }

        @Override
        public void onClick(View v) {
                switch (v.getId())
                {
                        case R.id.TabBtnWeChat:
                                t.setText("집 목록");
                                setTabSelection(0);
                                break;
                        case R.id.TabBtnFriend:
                                t.setText("집 추가하기");
                                setTabSelection(1);
                                break;
                        case R.id.TabBtnAddress:
                                t.setText("채팅");
                                setTabSelection(2);
                                break;
                        case R.id.TabBtnSettings:
                                t.setText("정보");
                                setTabSelection(3);
                                break;
                        default:
                                break;
                }
        }

        private void setTabSelection(int index)
        {
                resetBtn();
                FragmentTransaction transaction = fragmentManager.beginTransaction();
                hideFragments(transaction);
                switch (index) {
                        case 0:
                                ((ImageButton) mTabBtnWeChat.findViewById(R.id.imgWeChat)).setImageResource(R.drawable.tab_weixin_pressed);
                                if (mWeChat == null) {
                                        mWeChat = new MainWeChat();
                                        transaction.add(R.id.id_content, mWeChat);
                                } else {
                                        transaction.show(mWeChat);
                                }
                                break;
                        case 1:
                                ((ImageButton) mTabBtnFriend.findViewById(R.id.imgFriend)).setImageResource(R.drawable.tab_find_frd_pressed);
                                if (mFriend == null) {
                                        mFriend = new MainFriend();
                                        transaction.add(R.id.id_content, mFriend);
                                } else {
                                        transaction.show(mFriend);
                                }
                                break;
                        case 2:
                                ((ImageButton) mTabBtnAddress.findViewById(R.id.imgAddress)).setImageResource(R.drawable.tab_address_pressed);
                                if (mAddress == null) {
                                        mAddress = new MainAddress();
                                        transaction.add(R.id.id_content, mAddress);
                                } else {
                                        transaction.show(mAddress);
                                }
                                break;
                        case 3:
                                ((ImageButton) mTabBtnSettings.findViewById(R.id.imgSettings)).setImageResource(R.drawable.tab_settings_pressed);
                                if (mSettings == null) {
                                        mSettings = new MainSettings();
                                        transaction.add(R.id.id_content, mSettings);
                                } else {
                                        transaction.show(mSettings);
                                }
                                break;
                }transaction.commit();
        }
        private void resetBtn()
        {
                ((ImageButton) mTabBtnWeChat.findViewById(R.id.imgWeChat))
                        .setImageResource(R.drawable.tab_weixin_normal);
                ((ImageButton) mTabBtnFriend.findViewById(R.id.imgFriend))
                        .setImageResource(R.drawable.tab_find_frd_normal);
                ((ImageButton) mTabBtnAddress.findViewById(R.id.imgAddress))
                        .setImageResource(R.drawable.tab_address_normal);
                ((ImageButton) mTabBtnSettings.findViewById(R.id.imgSettings))
                        .setImageResource(R.drawable.tab_settings_normal);
        }

        private void hideFragments(FragmentTransaction transaction)
        {
                if (mWeChat != null)
                {
                        transaction.hide(mWeChat);
                }
                if (mFriend != null)
                {
                        transaction.hide(mFriend);
                }
                if (mAddress != null)
                {
                        transaction.hide(mAddress);
                }
                if (mSettings != null)
                {
                        transaction.hide(mSettings);
                }
        }
}