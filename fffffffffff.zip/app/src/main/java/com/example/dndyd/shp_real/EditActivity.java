package com.example.dndyd.shp_real;

import android.Manifest;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class EditActivity extends AppCompatActivity {
    Bitmap photo;
    private static final int PICK_FROM_GALLERY = 121;
    private static final int REQ_PERMISSION_GALLERY = 143;
    String imageUri_db;
    Uri imageUri;
    DatabaseReference db;
    FirebaseUser user;
    EditText pw, pwcheck, introduce;
    Spinner wakeupnoon, wakeup, sleepnoon, sleep;
    String newpw;
    String userid;
    String npw, npwcheck, nintroduce;
    int nwakeup, nsleep;
    ImageButton editBtn;
    Intent intent2;
    ImageView img;
    ImageButton imgBtn;
    Map<String, Object> infos;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit);
        infos = new HashMap<>();
        Intent intent = getIntent();
        intent2 = new Intent(this,SelectMenu.class);
        init();
        userid = intent.getStringExtra("userid");
        user = FirebaseAuth.getInstance().getCurrentUser();
        imgBtn = findViewById(R.id.edit_imageBtn);
        imgBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(checkAppPermission(new String[] {android.Manifest.permission.READ_EXTERNAL_STORAGE})) {
                    getAlbum();
                } else {
                    askPermission(new String[] {Manifest.permission.READ_EXTERNAL_STORAGE}, REQ_PERMISSION_GALLERY);
                }
            }
        });
        editBtn = findViewById(R.id.edit_editBtn);
        editBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                infoinit();
                db = FirebaseDatabase.getInstance().getReference("User");
                db.child(userid).updateChildren(infos);
                user.updatePassword(newpw)
                        .addOnCompleteListener(new OnCompleteListener<Void>() {
                            @Override
                            public void onComplete(@NonNull Task<Void> task) {
                                if(task.isSuccessful()) {
                                    Toast.makeText(getApplicationContext(), "비밀번호 수정 완료", Toast.LENGTH_SHORT).show();
                                }
                            }
                        });
                startActivity(intent2);
            }
        });
    }
    public void init() {
        pw = findViewById(R.id.edit_pw_editText);
        pwcheck = findViewById(R.id.edit_pwcheck_editText);
        introduce = findViewById(R.id.edit_introduce_editText);
        wakeupnoon = findViewById(R.id.edit_wakeup_noon_spinner);
        wakeup = findViewById(R.id.edit_wakeup_times_spinner);
        sleepnoon = findViewById(R.id.edit_sleep_noon_spinner);
        sleep = findViewById(R.id.edit_sleep_times_spinner);
        img = findViewById(R.id.edit_user_image);
    }

    public void infoinit() {
        newpw = pw.getText().toString();
        npw = newpw;
        npwcheck = pwcheck.getText().toString();
        nintroduce = introduce.getText().toString();
        nwakeup = nsleep = 0;
        if(wakeupnoon.getSelectedItemPosition() == 1) // 오후면
            nwakeup += 12;
        if(sleepnoon.getSelectedItemPosition() == 1) // 오후면
            nsleep += 12;
        infos.put("pw", npw);
        infos.put("pwcheck", npwcheck);
        infos.put("introduce", nintroduce);
        infos.put("wakeup", nwakeup);
        infos.put("sleep", nsleep);
        infos.put("image",imageUri_db);
    }

    public boolean checkAppPermission(String[] requestPermission) {
        boolean[] requestResult = new boolean[requestPermission.length];
        for(int i=0; i<requestResult.length; i++) {
            requestResult[i] = (ContextCompat.checkSelfPermission(this,
                    requestPermission[i]) == PackageManager.PERMISSION_GRANTED);
            if(!requestResult[i]) {
                return false;
            }
        }
        return true;
    }
    public void askPermission(String[] requestPermission, int REQ_PERMISSION) {
        ActivityCompat.requestPermissions(this, requestPermission, REQ_PERMISSION);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if(requestCode == RESULT_OK) {
            getAlbum();
        }
    }
    public void getAlbum() {
        Intent intent = new Intent(Intent.ACTION_PICK);
        intent.setType(MediaStore.Images.Media.CONTENT_TYPE);
        intent.setData(MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(intent, PICK_FROM_GALLERY);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if(resultCode == RESULT_OK) {
            if(requestCode == PICK_FROM_GALLERY) {
                try {
                    imageUri = data.getData();
                    photo = MediaStore.Images.Media.getBitmap(getContentResolver(), imageUri);
                    img.setImageBitmap(photo);
                } catch (Exception e) {
                    Log.e("test", e.getMessage());
                }
            }
        }
    }
    // FireBase Storage에 선택한 이미지 업로드하는 메소드
    public void uploadImage() {
        if(imageUri != null) {
            final ProgressDialog progressDialog = new ProgressDialog(this);

            progressDialog.setTitle("업로드 중..");
            progressDialog.show();

            FirebaseStorage storage = FirebaseStorage.getInstance();

            SimpleDateFormat formatter = new SimpleDateFormat("yyyyMMHH_mmss");
            Date now = new Date();
            String filename = formatter.format(now) + ".png";
            imageUri_db = "gs://gohome-563f2.appspot.com/profiles/"+filename;
            StorageReference storageRef = storage.getReferenceFromUrl("gs://gohome-563f2.appspot.com/")
                    .child("profiles/"+filename);
            storageRef.putFile(imageUri)
                    .addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                        @Override
                        public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                            progressDialog.dismiss();
                            Toast.makeText(getApplicationContext(), "사진 업로드 완료", Toast.LENGTH_SHORT).show();
                        }
                    })
                    .addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            progressDialog.dismiss();
                            Toast.makeText(getApplicationContext(), "사진 업로드 실패", Toast.LENGTH_SHORT).show();
                        }
                    })
                    .addOnProgressListener(new OnProgressListener<UploadTask.TaskSnapshot>() {
                        @Override
                        public void onProgress(UploadTask.TaskSnapshot taskSnapshot) {
                            @SuppressWarnings("VisibleForTests")
                            double progress = (100 * taskSnapshot.getBytesTransferred()) / taskSnapshot.getTotalByteCount();
                            progressDialog.setMessage("Uploaded " + ((int)progress) + "% ...");
                        }
                    });
        } else {

        }
    }
}