package com.example.dndyd.shp_real;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageMetadata;
import com.google.firebase.storage.StorageReference;
import com.squareup.picasso.Picasso;

public class partnerActivity extends AppCompatActivity {
    String user_id,partner_id;
    Intent intent;
    ImageView img;
    TextView textView, textView1, textView2, textView3, textView4,textView5,textView6,textView7,textView8,textView9,textView10;
    StorageReference storageReference;
    private FirebaseDatabase firebaseDatabase = FirebaseDatabase.getInstance();
    private DatabaseReference databaseReference = firebaseDatabase.getReference();
    FirebaseStorage storage = FirebaseStorage.getInstance();
    String introduce,id,email,wakeup,sleep,character,pet,birth_y,birth_m,birth_d,sex,pass,url;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_partner);

        intent =getIntent();
        user_id = intent.getStringExtra("userid");
        partner_id =intent.getStringExtra("partner");
        img = findViewById(R.id.profile_imageView);
        DatabaseReference db = FirebaseDatabase.getInstance().getReference("User");

        textView=(TextView)findViewById(R.id.partner_introduce_textView);
        textView1=(TextView)findViewById(R.id.partner_id_textView);
        textView2=(TextView)findViewById(R.id.partner_email_textView);
        textView3=(TextView)findViewById(R.id.partner_wakeup_textView);
        textView4=(TextView)findViewById(R.id.partner_sleep_textView);
        textView5=(TextView)findViewById(R.id.partner_pet_textView);
        textView7=(TextView)findViewById(R.id.partner_birthY_textView);
        textView8=(TextView)findViewById(R.id.partner_sex_textView);
        textView9=(TextView)findViewById(R.id.partner_birthM_textView);
        textView10=(TextView)findViewById(R.id.partner_birthD_textView);

        Query query = db.orderByKey();
        query.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                for(DataSnapshot data : dataSnapshot.getChildren()) {
                    if(data.getKey().equals(partner_id)) {
                        url = data.child("image").getValue().toString();
                        firebaseDatabase=FirebaseDatabase.getInstance();
                        introduce = data.child("introduce").getValue().toString();
                        id = data.child("id").getValue().toString();
                        email = data.child("email").getValue().toString();
                        wakeup = data.child("wakeup").getValue().toString();
                        sleep = data.child("sleep").getValue().toString();
                        pet = data.child("pet").getValue().toString();
                        birth_y = data.child("birth_year").getValue().toString();
                        birth_m = data.child("birth_month").getValue().toString();
                        birth_d = data.child("birth_day").getValue().toString();
                        sex = data.child("sex").getValue().toString();
                        textView.setText(introduce);
                        textView1.setText(id);
                        textView2.setText(email);
                        textView3.setText(wakeup);
                        textView4.setText(sleep);
                         if(pet.equals("false")){
                                 textView5.setText("없음");}
                        else{
                            textView5.setText("있음");
                        }
                         textView7.setText(birth_y);
                        textView8.setText(sex);
                        textView9.setText(birth_m);
                        textView10.setText(birth_d);

                        StorageReference storageReference = storage.getReferenceFromUrl(url);
                        storageReference.getMetadata().addOnSuccessListener(new OnSuccessListener<StorageMetadata>() {
                            @Override
                            public void onSuccess(StorageMetadata storageMetadata) {
                                Picasso.with(getApplicationContext()).load(storageMetadata.getDownloadUrl()).into(img);
                            }
                        });
                        break;
                    } else {
                    }
                }

            }
            @Override
            public void onCancelled(DatabaseError databaseError) {
                Log.e("SignupActivity", databaseError.getMessage());
            }
        });
    }

    public void partner(View view) {
        DatabaseReference db = FirebaseDatabase.getInstance().getReference("User");
        db.child(user_id).child("partner_r").setValue(partner_id);
        db.child(partner_id).child("partner_r").setValue(user_id);
        Intent intent2 = new Intent(getApplicationContext(),SelectMenu.class);
        intent2.putExtra("userid",user_id);
        intent2.putExtra("partnerid",partner_id);
        startActivity(intent2);
    }
}

