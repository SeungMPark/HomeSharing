package com.example.dndyd.shp_real;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;

public class HomeMenu extends AppCompatActivity {
    double lat,lon;
    String userid;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_menu);
        Intent intent = getIntent();
        userid = intent.getStringExtra("userid");
        init();
    }

    public void init() {
        FirebaseStorage storage = FirebaseStorage.getInstance();
        DatabaseReference db = FirebaseDatabase.getInstance().getReference("User");
        db.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                // id 부분에 intent로 받은 id정보 넣으면 됩니다.
                lat =   Double.parseDouble(dataSnapshot.child("dndyd1231").child("lat").getValue().toString());
                lon =   Double.parseDouble(dataSnapshot.child("dndyd1231").child("lon").getValue().toString());
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
            }
        });
    }
    public void btn1(View view) {
        Intent i=new Intent(getApplicationContext(),HomeList.class);
        i.putExtra("userid", userid);
        startActivity(i);
    }
    public void btn2(View view) {

        Intent i=new Intent(getApplicationContext(),AddressActivity2.class);


        i.putExtra("lat",lat);
        i.putExtra("lon",lon);

        //Toast.makeText(this, Double.toString(lat), Toast.LENGTH_SHORT).show();

        startActivity(i);
    }
}
