package com.example.dndyd.shp_real;

import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class SelectMenu extends AppCompatActivity {
    ImageButton btn1,btn2,btn3,btn4;
    DatabaseReference db;
    boolean yes = false; // 이따가 false로 바꿔줘야함
    String user_id, partner;
    boolean asdf;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_select_menu);
        db = FirebaseDatabase.getInstance().getReference("User");
        Intent intent = getIntent();
        user_id = intent.getStringExtra("userid");
        db.orderByChild(user_id).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                if(dataSnapshot.getKey().equals(user_id)) {
                    if((boolean)dataSnapshot.child("partner_b").getValue()) {
                        yes = true;
                    }
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });
        if(yes) {
            db.orderByKey().equalTo(user_id).addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(DataSnapshot dataSnapshot) {
                    for(DataSnapshot data : dataSnapshot.getChildren()) {
                        if (dataSnapshot.getKey().equals(user_id)) {
                            partner = dataSnapshot.child("partner").getValue().toString();
                        }
                    }
                }

                @Override
                public void onCancelled(DatabaseError databaseError) {

                }
            });
            if(makeDialog(partner)) {
                Intent intent123 = new Intent(getApplicationContext(),MyProfile.class);
                intent123.putExtra("userid",partner);
                startActivity(intent123);
            } else { }

        }

        btn1 = (ImageButton)findViewById(R.id.select_btn1);
        btn2 = (ImageButton)findViewById(R.id.select_btn2);
        btn3 = (ImageButton)findViewById(R.id.select_btn3);
        btn4 = (ImageButton)findViewById(R.id.select_btn4);

        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),HomeMenu.class);
                intent.putExtra("userid",user_id);
                startActivity(intent);
            }
        });

        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),HomeRegistActivity.class);
                intent.putExtra("userid",user_id);
                startActivity(intent);
            }
        });

        btn3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),MatchingChatting.class);
                intent.putExtra("userid",user_id);
                startActivity(intent);
            }
        });

        btn4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),MyProfile.class);
                intent.putExtra("userid",user_id);
                startActivity(intent);
            }
        });
    }
    public boolean makeDialog(String partner) {
        LayoutInflater dialog = LayoutInflater.from(this);
        View dialogLayout = dialog.inflate(R.layout.layout_partnercheck, null);
        final Dialog checkDialog = new Dialog(this);

        checkDialog.setTitle("회원님이 등록한 집에 신청인이 있습니다!");
        checkDialog.setContentView(dialogLayout);
        checkDialog.show();

        TextView partnerid = (TextView)dialogLayout.findViewById(R.id.partner_id_textView);
        partnerid.setText(partner);
        Button yeah = (Button)dialogLayout.findViewById(R.id.partner_yesbtn);
        Button nope = (Button)dialogLayout.findViewById(R.id.partner_nobtn);
        yeah.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 텍스트뷰에 있는 아이디 인텐트로 넘겨서 정보 보여주는 화면(MyProfile 레이아웃 그대로 쓰면 될듯)으로 넘어가면 될듯
                asdf = true;
            }
        });
        nope.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkDialog.cancel();
                asdf = false;
            }
        });
        return asdf;
    }
}
