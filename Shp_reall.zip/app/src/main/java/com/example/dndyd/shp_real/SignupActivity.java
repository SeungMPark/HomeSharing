package com.example.dndyd.shp_real;

import android.Manifest;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.iid.FirebaseInstanceId;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.text.SimpleDateFormat;
import java.util.Date;

/* 18.06.02(토) 21:49 기준 진행상황
FireBase Authenticaion, Realtime Database, Storage와 연동하여
이메일과 패스워드로 회원 정보 저장되고
실시간 데이터베이스에 유저가 입력한 정보들 넣었고
사진 업로드해서 저장소에 업로드돼고, 그 주소도 데이터베이스의 해당 유저 테이블에 저장하였음

이제 해야할거는
아이디 중복확인, 패스워드 체크, 이메일 인증 기능 추가해서 넣어야함!
*/

public class SignupActivity extends AppCompatActivity {

    String imageUri_db;
    Uri imageUri;
    Bitmap photo;
    ImageView userimage;
    private static final int PICK_FROM_GALLERY = 111;
    private static final int REQ_PERMISSION_GALLERY = 123;

    private FirebaseDatabase firebaseDatabase = FirebaseDatabase.getInstance();
    private DatabaseReference databaseReference = firebaseDatabase.getReference();
    String TAG = "SignupActivity";
    private FirebaseAuth mAuth;
    private FirebaseAuth.AuthStateListener mAuthListener;
    public User user;
    // 이름들은 그냥 그대로임
    EditText joinid, joinpassword, joinpasswordcheck, joinemail, joinintroduce;
    RadioGroup joinsexradiogroup, jointyperadiogroup, joinhavepetradiogroup;
    boolean ismale, isjunior, silence, quiet, calm, pleasantness, sensitive, havepet;
    Spinner year_spinner, month_spinner, day_spinner, wakeup_noon_spinner, wakeup_spinner, sleep_spinner, sleep_noon_spinner;
    int year, month, day, wake_up_time, sleep_time;
    String id, pw, pwcheck, email, introduce;
    CheckBox silencecheckBox, quietcheckBox, pleasantnesscheckBox, sensitivecheckBox;
    String tokenID = FirebaseInstanceId.getInstance().getToken();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);
        authinit();
        init();
        Button registerBtn = findViewById(R.id.submit);
        registerBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                createUserInfo();
                registerUser(email, pw);
                // 이 밑에는 FireBase Realtime Database에 User 정보를 테이블로 저장하는 구문임
                databaseReference.child("User").child(tokenID).child("id").setValue(user.id);
                databaseReference.child("User").child(tokenID).child("pw").setValue(user.pw);
                databaseReference.child("User").child(tokenID).child("email").setValue(user.email);
                databaseReference.child("User").child(tokenID).child("introduce").setValue(user.introduce);
                databaseReference.child("User").child(tokenID).child("birth_year").setValue(user.birth_year);
                databaseReference.child("User").child(tokenID).child("birth_month").setValue(user.birth_month);
                databaseReference.child("User").child(tokenID).child("birth_day").setValue(user.birth_day);
                databaseReference.child("User").child(tokenID).child("wakeup").setValue(user.wakeup);
                databaseReference.child("User").child(tokenID).child("sleep").setValue(user.sleep);
                databaseReference.child("User").child(tokenID).child("silence").setValue(user.silence);
                databaseReference.child("User").child(tokenID).child("quiet").setValue(user.quiet);
                databaseReference.child("User").child(tokenID).child("calm").setValue(user.calm);
                databaseReference.child("User").child(tokenID).child("pleasantness").setValue(user.pleasantness);
                databaseReference.child("User").child(tokenID).child("sensitive").setValue(user.sensitive);
                databaseReference.child("User").child(tokenID).child("pet").setValue(user.pet);
                databaseReference.child("User").child(tokenID).child("idcard").setValue(user.idcard);
                uploadImage();
                databaseReference.child("User").child(tokenID).child("image").setValue(imageUri_db);
            }
        });
    }
    // Firebase Authentication 객체들을 초기화하는 메소드
    private void authinit() {
        mAuth = FirebaseAuth.getInstance();
        mAuthListener = new FirebaseAuth.AuthStateListener() {
            @Override
            public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
                FirebaseUser fbuser = firebaseAuth.getCurrentUser();
                if(fbuser != null) {
                    Log.d(TAG, "onAuthStateChanged:signed_in"+fbuser.getUid());
                } else {
                    Log.d(TAG, "onAuthStateChanged:signed_out");
                }
            }
        };
    }
    // activity_signup에 있는 뷰들 초기화하는 메소드
    private void init() {
        userimage = findViewById(R.id.join_imageView);
        joinid = findViewById(R.id.join_id_editText);
        joinpassword = findViewById(R.id.join_pw_editText);
        joinpasswordcheck = findViewById(R.id.join_pw_check_editText);
        joinemail = findViewById(R.id.authEmail);
        joinintroduce = findViewById(R.id.join_introduce_editText);
        joinsexradiogroup = findViewById(R.id.join_sex_radioGroup);
        jointyperadiogroup = findViewById(R.id.join_type_radioGroup);
        year_spinner = findViewById(R.id.join_years_spinner);
        month_spinner = findViewById(R.id.join_months_spinner);
        day_spinner = findViewById(R.id.join_days_spinner);
        wakeup_noon_spinner = findViewById(R.id.join_wakeup_noon_spinner);
        wakeup_spinner = findViewById(R.id.join_wakeup_times_spinner);
        sleep_noon_spinner = findViewById(R.id.join_sleep_noon_spinner);
        sleep_spinner = findViewById(R.id.join_sleep_times_spinner);
        silencecheckBox = findViewById(R.id.join_silence_checkBox);
        quietcheckBox = findViewById(R.id.join_quiet_checkBox);
        pleasantnesscheckBox = findViewById(R.id.join_pleasantness_checkBox);
        sensitivecheckBox = findViewById(R.id.join_sensitive_checkBox);
        joinhavepetradiogroup = findViewById(R.id.join_havepet_radioGroup);
    }
    // activity_signup에 있는 뷰들의 정보를 받아와서 User 객체 만들어주는 메소드
    public void createUserInfo() {
        email = joinemail.getText().toString();
        id = joinid.getText().toString();
        pw = joinpassword.getText().toString();
        pwcheck = joinpasswordcheck.getText().toString();
        introduce = joinintroduce.getText().toString();
        year = Integer.parseInt(year_spinner.getSelectedItem().toString());
        month = Integer.parseInt(month_spinner.getSelectedItem().toString());
        day = Integer.parseInt(day_spinner.getSelectedItem().toString());
        wake_up_time = 0;
        sleep_time = 0;
        if(wakeup_noon_spinner.getSelectedItemPosition() == 1)
            wake_up_time += 12;
        if(sleep_noon_spinner.getSelectedItemPosition() == 1)
            sleep_time += 12;
        wake_up_time += Integer.parseInt(wakeup_spinner.getSelectedItem().toString());
        sleep_time += Integer.parseInt(sleep_spinner.getSelectedItem().toString());
        joinsexradiogroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                switch(checkedId) {
                    case R.id.join_male_radioBtn:
                        ismale = true;
                        break;
                    case R.id.join_female_radioBtn:
                        ismale = false;
                        break;
                }
            }
        });
        jointyperadiogroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                switch(checkedId) {
                    case R.id.join_junior_radioBtn:
                        isjunior = true;
                        break;
                    case R.id.join_senior_radioBtn:
                        isjunior = false;
                        break;
                }
            }
        });
        joinhavepetradiogroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                switch(checkedId) {
                    case R.id.join_have_radioBtn:
                        havepet = true;
                        break;
                    case R.id.join_havenot_radioBtn:
                        havepet = false;
                        break;
                }
            }
        });
        user = new User(ismale, isjunior, silence, quiet, calm, pleasantness, sensitive, havepet);
        user.setEmail(email);
        user.setId(id);
        user.setPw(pw);
        user.setPwcheck(pwcheck);
        user.setBirth_year(year);
        user.setBirth_month(month);
        user.setBirth_day(day);
        user.setIntroduce(introduce);
        user.setWakeup(wake_up_time);
        user.setSleep(sleep_time);
    }
    // 회원가입 버튼 눌렀을 때 호출되는 메소드. FireBase Authentication에 유저의 이메일과 비밀번호를 저장한다
    public void registerUser(String email, String password) {
        mAuth.createUserWithEmailAndPassword(email, password)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if(task.isSuccessful()) {
                            Toast.makeText(getApplicationContext(), "회원가입 성공", Toast.LENGTH_SHORT).show();
                        } else {
                            Toast.makeText(getApplicationContext(), "회원가입 실패", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
    }
    @Override
    public void onStart() {
        super.onStart();
        // Check if user is signed in (non-null) and update UI accordingly.
        FirebaseUser currentUser = mAuth.getCurrentUser();
        mAuth.addAuthStateListener(mAuthListener);
    }

    @Override
    protected void onStop() {
        super.onStop();
        if(mAuthListener != null) {
            mAuth.removeAuthStateListener(mAuthListener);
        }
    }

    public void imageBtnClick(View view) {
        if(checkAppPermission(new String[] {android.Manifest.permission.READ_EXTERNAL_STORAGE})) {
            getAlbum();
        } else {
            askPermission(new String[] {Manifest.permission.READ_EXTERNAL_STORAGE}, REQ_PERMISSION_GALLERY);
        }
    }
    public boolean checkAppPermission(String[] requestPermission) {
        boolean[] requestResult = new boolean[requestPermission.length];
        for(int i=0; i<requestResult.length; i++) {
            requestResult[i] = (ContextCompat.checkSelfPermission(this,
                    requestPermission[i]) == PackageManager.PERMISSION_GRANTED);
            if(!requestResult[i]) {
                return false;
            }
        }
        return true;
    }
    public void askPermission(String[] requestPermission, int REQ_PERMISSION) {
        ActivityCompat.requestPermissions(this, requestPermission, REQ_PERMISSION);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if(requestCode == RESULT_OK) {
            getAlbum();
        }
    }
    public void getAlbum() {
        Intent intent = new Intent(Intent.ACTION_PICK);
        intent.setType(MediaStore.Images.Media.CONTENT_TYPE);
        intent.setData(MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(intent, PICK_FROM_GALLERY);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if(resultCode == RESULT_OK) {
            if(requestCode == PICK_FROM_GALLERY) {
                try {
                    imageUri = data.getData();
                    photo = MediaStore.Images.Media.getBitmap(getContentResolver(), imageUri);
                    userimage.setImageBitmap(photo);
                } catch (Exception e) {
                    Log.e("test", e.getMessage());
                }
            }
        }
    }
    // FireBase Storage에 선택한 이미지 업로드하는 메소드
    public void uploadImage() {
        if(imageUri != null) {
            final ProgressDialog progressDialog = new ProgressDialog(this);

            progressDialog.setTitle("업로드 중..");
            progressDialog.show();

            FirebaseStorage storage = FirebaseStorage.getInstance();

            SimpleDateFormat formatter = new SimpleDateFormat("yyyyMMHH_mmss");
            Date now = new Date();
            String filename = formatter.format(now) + ".png";
            imageUri_db = "gs://gohome-563f2.appspot.com/profiles/"+filename;
            StorageReference storageRef = storage.getReferenceFromUrl("gs://gohome-563f2.appspot.com/")
                    .child("profiles/"+filename);
            storageRef.putFile(imageUri)
                    .addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                        @Override
                        public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                            progressDialog.dismiss();
                            Toast.makeText(getApplicationContext(), "사진 업로드 완료", Toast.LENGTH_SHORT).show();
                        }
                    })
                    .addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            progressDialog.dismiss();
                            Toast.makeText(getApplicationContext(), "사진 업로드 실패", Toast.LENGTH_SHORT).show();
                        }
                    })
                    .addOnProgressListener(new OnProgressListener<UploadTask.TaskSnapshot>() {
                        @Override
                        public void onProgress(UploadTask.TaskSnapshot taskSnapshot) {
                            @SuppressWarnings("VisibleForTests")
                                    double progress = (100 * taskSnapshot.getBytesTransferred()) / taskSnapshot.getTotalByteCount();
                            progressDialog.setMessage("Uploaded " + ((int)progress) + "% ...");
                        }
                    });
        } else {
            Toast.makeText(getApplicationContext(), "파일을 먼저 선택하세요", Toast.LENGTH_SHORT).show();
        }
    }
}
