package com.example.dndyd.shp_real;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.StaggeredGridLayoutManager;
import android.view.View;

import java.util.ArrayList;
import java.util.List;

public class HomeList extends AppCompatActivity {

    private RecyclerView recyclerView;
    private List<Beauty> data = new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_list);

        recyclerView = (RecyclerView)findViewById(R.id.recycler_view);
        StaggeredGridLayoutManager recyclerViewLayoutManager =
                new StaggeredGridLayoutManager(2, StaggeredGridLayoutManager.VERTICAL);
        recyclerView.setLayoutManager(recyclerViewLayoutManager);
        initData();
        BeautyAdapter adapter = new BeautyAdapter(data,this);
        recyclerView.setAdapter(adapter);
    }
    private void initData() {
        Beauty beauty;
        beauty = new Beauty("美女1" , R.drawable.ic_launcher_background);
        data.add(beauty);
        beauty = new Beauty("美女2", R.mipmap.ic_launcher);
        data.add(beauty);
        beauty = new Beauty("美女", R.mipmap.ic_launcher);
        data.add(beauty);
        beauty = new Beauty("美女", R.mipmap.ic_launcher);
        data.add(beauty);
        beauty = new Beauty("美女", R.mipmap.ic_launcher);
        data.add(beauty);
        beauty = new Beauty("美女", R.mipmap.ic_launcher);
        data.add(beauty);
        beauty = new Beauty("美女", R.mipmap.ic_launcher);
        data.add(beauty);
        beauty = new Beauty("美女", R.mipmap.ic_launcher);
        data.add(beauty);
        beauty = new Beauty("美女", R.mipmap.ic_launcher);
        data.add(beauty);
        beauty = new Beauty("美女", R.mipmap.ic_launcher);
        data.add(beauty);
        beauty = new Beauty("美女1" , R.drawable.ic_launcher_background);
        data.add(beauty);
        beauty = new Beauty("美女2", R.mipmap.ic_launcher);
        data.add(beauty);
        beauty = new Beauty("美女", R.mipmap.ic_launcher);
        data.add(beauty);
        beauty = new Beauty("美女", R.mipmap.ic_launcher);
        data.add(beauty);
        beauty = new Beauty("美女", R.mipmap.ic_launcher);
        data.add(beauty);
        beauty = new Beauty("美女", R.mipmap.ic_launcher);
        data.add(beauty);
        beauty = new Beauty("美女", R.mipmap.ic_launcher);
        data.add(beauty);
        beauty = new Beauty("美女", R.mipmap.ic_launcher);
        data.add(beauty);
        beauty = new Beauty("美女", R.mipmap.ic_launcher);
        data.add(beauty);
        beauty = new Beauty("美女", R.mipmap.ic_launcher);
        data.add(beauty);
        beauty = new Beauty("美女1" , R.drawable.ic_launcher_background);
        data.add(beauty);
        beauty = new Beauty("美女2", R.mipmap.ic_launcher);
        data.add(beauty);
        beauty = new Beauty("美女", R.mipmap.ic_launcher);
        data.add(beauty);
        beauty = new Beauty("美女", R.mipmap.ic_launcher);
        data.add(beauty);
        beauty = new Beauty("美女", R.mipmap.ic_launcher);
        data.add(beauty);
        beauty = new Beauty("美女", R.mipmap.ic_launcher);
        data.add(beauty);
        beauty = new Beauty("美女", R.mipmap.ic_launcher);
        data.add(beauty);
        beauty = new Beauty("美女", R.mipmap.ic_launcher);
        data.add(beauty);
        beauty = new Beauty("美女", R.mipmap.ic_launcher);
        data.add(beauty);
        beauty = new Beauty("美女", R.mipmap.ic_launcher);
        data.add(beauty);

    }
}
