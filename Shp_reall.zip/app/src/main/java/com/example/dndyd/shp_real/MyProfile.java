package com.example.dndyd.shp_real;

import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;

import com.example.dndyd.shp_real.R;

public class MyProfile extends AppCompatActivity {
    Button editBtn;
    Intent intent;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_profile);
        intent = new Intent(this, MainActivity.class);
        editBtn = (Button)findViewById(R.id.profile_editBtn);
        editBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showDialog();
            }
        });
    }
    public void showDialog() {
        final LayoutInflater dialog = LayoutInflater.from(this);
        final View dialogLayout = dialog.inflate(R.layout.layout_dialog, null);
        final Dialog pwDialog = new Dialog(this);

        pwDialog.setTitle("비밀번호를 입력해주세요");
        pwDialog.setContentView(dialogLayout);
        pwDialog.show();

        Button btn_ok = (Button)dialogLayout.findViewById(R.id.edit_passwordOKBtn);
        Button btn_cancel = (Button)dialogLayout.findViewById(R.id.edit_passwordCancelBtn);
        btn_ok.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 현재 비밀번호가 맞다면 (check하는 부분 넣어줘야됨)
                // 정보 수정하는 곳으로 고고
                startActivity(intent);
            }
        });
        btn_cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pwDialog.cancel();
            }
        });

    }
}