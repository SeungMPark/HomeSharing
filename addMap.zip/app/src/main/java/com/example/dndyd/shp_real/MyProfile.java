package com.example.dndyd.shp_real;

import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.support.constraint.solver.widgets.Snapshot;
import android.support.v7.app.AppCompatActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.dndyd.shp_real.R;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class MyProfile extends AppCompatActivity {
    Button editBtn;
    Intent intent;
    String pass;
    TextView textView, textView1, textView2, textView3, textView4;
    private FirebaseDatabase firebaseDatabase = FirebaseDatabase.getInstance();
    private DatabaseReference databaseReference = firebaseDatabase.getReference();
    String TokenId="czHgcL_peR8:APA91bEG_jcDLESJ1bJVbOreVDykdj1Hi1bomGGG3mmsuAbyt8ndgYAsIcR3kbp26ZCxR48CXe_-JZmHMCvubl1SUuUGkezcai35dhhNlnBJPHolJ7pIolDkdvACbhF9GGR7_YYtC1ol";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_profile);
        intent = new Intent(this, EditActivity.class);
        init();
        firebaseDatabase=FirebaseDatabase.getInstance();
        textView=(TextView)findViewById(R.id.profile_introduce_textView);
        textView1=(TextView)findViewById(R.id.profile_id_textView);
        textView2=(TextView)findViewById(R.id.profile_name_textView);
        textView3=(TextView)findViewById(R.id.profile_grade_textView);
        textView4=(TextView)findViewById(R.id.profile_phone_textView);
        firebaseDatabase.getReference().child("User").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                textView.setText(dataSnapshot.child(TokenId).child("introduce").getValue().toString());
                textView1.setText(dataSnapshot.child(TokenId).child("id").getValue().toString());
                textView2.setText(dataSnapshot.child(TokenId).child("calm").getValue().toString());
                pass=dataSnapshot.child(TokenId).child("pw").getValue().toString();
                Toast.makeText(MyProfile.this, pass, Toast.LENGTH_SHORT).show();
                //  textView4.setText(dataSnapshot.child(TokenId).child("sleep").getValue().toString());
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });


        editBtn = (Button)findViewById(R.id.profile_editBtn);
        editBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showDialog();
            }
        });
    }

    private void init() {

    }

    public void showDialog() {
        final LayoutInflater dialog = LayoutInflater.from(this);
        final View dialogLayout = dialog.inflate(R.layout.layout_dialog, null);
        final Dialog pwDialog = new Dialog(this);

        pwDialog.setTitle("비밀번호를 입력해주세요");
        pwDialog.setContentView(dialogLayout);
        pwDialog.show();

        Button btn_ok = (Button)dialogLayout.findViewById(R.id.edit_passwordOKBtn);
        Button btn_cancel = (Button)dialogLayout.findViewById(R.id.edit_passwordCancelBtn);
        btn_ok.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 현재 비밀번호가 맞다면 (check하는 부분 넣어줘야됨)
                // 정보 수정하는 곳으로 고고
                EditText editText=(EditText)dialogLayout.findViewById(R.id.edit_password_editText);

                if(editText.getText().toString().equals(pass))
                    startActivity(intent);
                else
                    Toast.makeText(MyProfile.this, "비밀번호가 올바르지않습니다", Toast.LENGTH_SHORT).show();
            }
        });
        btn_cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pwDialog.cancel();
            }
        });

    }
}